Please visit https://mesofthorny.github.io/WTRTI/ for the documentation.
